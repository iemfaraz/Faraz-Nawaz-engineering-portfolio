// Cloudflare Worker that stores your latest approximate position.
// Bindings you create in Cloudflare: KV namespace "LOC", secret "TOKEN", variable "ALLOWED_ORIGIN".
//   GET  /        -> latest position (public, already rounded)
//   POST /update  -> body {"lat":24.71,"lon":46.67,"label":"Riyadh"}  header "Authorization: Bearer <TOKEN>"
//   POST /clear   -> removes the position (turns the widget off)  header "Authorization: Bearer <TOKEN>"
const round = v => Math.round(v * 20) / 20;           // about 5 km grid
export default {
  async fetch(req, env) {
    const cors = {
      'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Cache-Control': 'no-store'
    };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    const url = new URL(req.url);
    if (req.method === 'GET') {
      const v = await env.LOC.get('loc');
      return new Response(v || '{}', { headers: { ...cors, 'Content-Type': 'application/json' } });
    }
    if (req.method === 'POST' && (url.pathname === '/update' || url.pathname === '/clear')) {
      if (req.headers.get('Authorization') !== 'Bearer ' + env.TOKEN) return new Response('Unauthorized', { status: 401, headers: cors });
      if (url.pathname === '/clear') { await env.LOC.delete('loc'); return new Response('cleared', { headers: cors }); }
      const b = await req.json().catch(() => ({}));
      const lat = Number(b.lat), lon = Number(b.lon);
      if (!isFinite(lat) || !isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return new Response('Bad request', { status: 400, headers: cors });
      const out = { lat: round(lat), lon: round(lon), label: String(b.label || '').slice(0, 60), ts: Date.now() };
      await env.LOC.put('loc', JSON.stringify(out));
      return new Response('ok', { headers: cors });
    }
    return new Response('Not found', { status: 404, headers: cors });
  }
};
