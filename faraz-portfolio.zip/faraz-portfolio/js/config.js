// Live location settings.
// Leave "endpoint" empty to hide the widget completely.
window.LIVE_CONFIG = {
  endpoint: "",            // e.g. "https://faraz-location.YOURNAME.workers.dev/"
  defaultLabel: "Riyadh",  // shown when the sender does not provide a place name
  refreshSeconds: 120,     // how often the page asks for a fresh position
  staleHours: 12,          // after this long the widget shows "Last seen" in grey
  circleMeters: 2500       // radius of the circle drawn on the map (no exact pin)
};
