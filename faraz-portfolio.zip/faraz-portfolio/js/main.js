(function () {
  var root = document.documentElement;
  var EN = {}, META = { title: document.title, desc: document.querySelector('meta[name=description]').content };
  var nodes = document.querySelectorAll('[data-i18n]');
  nodes.forEach(function (n) { EN[n.dataset.i18n] = n.innerHTML; });   // snapshot English from the page

  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} }

  function setLang(l) {
    var ar = l === 'ar';
    root.lang = ar ? 'ar' : 'en';
    root.dir = ar ? 'rtl' : 'ltr';
    nodes.forEach(function (n) {
      var k = n.dataset.i18n, v = ar ? window.AR[k] : EN[k];
      if (v != null) n.innerHTML = v;
    });
    var m = ar ? window.AR_META : META;
    document.title = m.title;
    document.querySelector('meta[name=description]').content = m.desc;
    document.getElementById('lang').textContent = ar ? 'English' : 'عربي';
    store('lang', l);
  }

  // language: ?lang=ar, then saved choice, then browser language
  var q = /[?&]lang=(ar|en)/.exec(location.search);
  var saved = q ? q[1] : store('lang');
  var start = saved || ((navigator.language || '').toLowerCase().indexOf('ar') === 0 ? 'ar' : 'en');
  if (start === 'ar') setLang('ar');
  document.getElementById('lang').addEventListener('click', function () { setLang(root.lang === 'ar' ? 'en' : 'ar'); });

  // theme
  var t = store('theme'); if (t) root.dataset.theme = t;
  document.getElementById('theme').addEventListener('click', function () {
    var dark = root.dataset.theme ? root.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme:dark)').matches;
    root.dataset.theme = dark ? 'light' : 'dark'; store('theme', root.dataset.theme);
  });

  // smooth scroll
  document.querySelectorAll('.links a').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var el = document.getElementById(a.dataset.t);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // project filters
  document.getElementById('chips').addEventListener('click', function (e) {
    var b = e.target.closest('.chip'); if (!b) return;
    document.querySelectorAll('.chip').forEach(function (x) { x.classList.toggle('on', x === b); });
    var f = b.dataset.f;
    document.querySelectorAll('#pg .card').forEach(function (c) { c.hidden = !(f === 'all' || c.dataset.c === f); });
  });

  // reveal on scroll + count-up
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    document.querySelectorAll('.rv').forEach(function (n) { n.classList.add('pre'); io.observe(n); });
    var co = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return; co.unobserve(e.target);
        var end = +e.target.dataset.count, s = performance.now();
        (function f(now) { var p = Math.min((now - s) / 900, 1); e.target.textContent = Math.round(end * p); if (p < 1) requestAnimationFrame(f); })(s);
      });
    });
    document.querySelectorAll('[data-count]').forEach(function (n) { co.observe(n); });
  }
})();
