(function () {
  var C = window.LIVE_CONFIG || {};
  var box = document.getElementById('live');
  if (!box || !C.endpoint) return;               // not configured: widget stays hidden
  var map, circle, mapEl = document.getElementById('live-map');

  function ago(ms) {
    var m = Math.round(ms / 60000);
    if (m < 2) return 'just now';
    if (m < 60) return m + ' minutes ago';
    var h = Math.round(m / 60);
    if (h < 48) return h + (h === 1 ? ' hour ago' : ' hours ago');
    return Math.round(h / 24) + ' days ago';
  }
  function round(v) { return Math.round(v * 20) / 20; }   // about 5 km grid, never an exact spot

  function render(d) {
    if (!d || typeof d.lat !== 'number' || typeof d.lon !== 'number' || !d.ts) { box.hidden = true; return; }
    var age = Date.now() - d.ts, stale = age > C.staleHours * 3600000;
    var label = d.label || C.defaultLabel || 'my area';
    document.getElementById('live-title').textContent = (stale ? 'Last seen around ' : 'Currently around ') + label;
    document.getElementById('live-sub').textContent = 'Updated ' + ago(age);
    document.getElementById('live-dot').className = 'dot' + (stale ? ' off' : '');
    box.hidden = false;
    if (window.L) {
      var p = [round(d.lat), round(d.lon)];
      mapEl.hidden = false;
      if (!map) {
        map = L.map(mapEl, { zoomControl: false, scrollWheelZoom: false, dragging: false, attributionControl: true }).setView(p, 11);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 14, attribution: '&copy; OpenStreetMap' }).addTo(map);
        circle = L.circle(p, { radius: C.circleMeters || 2500, color: '#c5963c', fillColor: '#c5963c', fillOpacity: 0.25 }).addTo(map);
      } else { circle.setLatLng(p); map.setView(p, 11); }
    }
  }
  function load() {
    fetch(C.endpoint, { cache: 'no-store' }).then(function (r) { return r.json(); }).then(render).catch(function () { box.hidden = true; });
  }
  window.addEventListener('load', function () { load(); setInterval(load, (C.refreshSeconds || 120) * 1000); });
})();
